using UnityEngine;

public class ArrancaMato : MonoBehaviour
{
    public int damage = 35;
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.GetComponent<MatoHealth>() && Input.GetButtonDown("mouse 0"))
        {
            collision.gameObject.GetComponent<MatoHealth>().matoHealth -= damage;
        }
    }
}
