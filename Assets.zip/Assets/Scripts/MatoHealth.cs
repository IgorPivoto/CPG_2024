using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using TMPro;

public class MatoHealth : MonoBehaviour
{
    public GameObject popUpDamagePrefab;
    public TMP_Text popUpText;
    public GameObject[] lootToDrop;
    public float delayTime = .15f;
    public int matoHealth;
    public int matoMaxHealth;

    public GameObject[] itemDrops;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        matoHealth = matoMaxHealth;
    }

    public void TakeDamage(int damage){
        matoHealth -= damage;
        //popUpText.next = TakeDamage.ToString();
        //Instantiate(popUpDamagePrefab, transform.position, Quaternion.identity);
        StartCoroutine(knockbackDelay());
    }

    IEnumerator knockbackDelay(){
        yield return new WaitForSeconds(delayTime);
        if(matoHealth <= 0){
            int randomNum = Random.Range(0, lootToDrop.Length);
            Instantiate(lootToDrop[randomNum], transform.position, Quaternion.identity);
            Destroy(gameObject);
        }

        else {
            GetComponent<Rigidbody2D>().velocity = Vector2.zero;
        }
    }
    void Update()
    {
        if (matoHealth <= 0){
            ItemDrop();
        }
    }

    private void ItemDrop()
    {
        for (int i = 0; i < itemDrops.Length; i++){
            Instantiate(itemDrops[i], transform.position + new Vector3(0, 1, 0), Quaternion.identity);
        }
    }
}
