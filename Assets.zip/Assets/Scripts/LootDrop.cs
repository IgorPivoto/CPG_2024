using UnityEngine;

public class LootDrop : MonoBehaviour
{
    private Rigidbody2D itemRb;
    public float dropForce = 5;
    public int quantity;
    public LootType lootType;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        itemRb = GetComponent<Rigidbody2D>();
        itemRb.AddForce(Vector2.up * dropForce, ForceMode2D.Impulse);
    }
}

public enum LootType
{
    Dinheiro,
    Metal,
    Cigarro,

};
