using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class SelfDestruct : MonoBehaviour
{
    public float destructionTime;
    private float timer;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    public void Start()
    {
        timer = destructionTime;
    }
    // Update is called once per frame
    public void Update()
    {
        timer -= Time.deltaTime;

        if (timer <= 0)
        {
            Destroy(gameObject);
        }
    }
}


